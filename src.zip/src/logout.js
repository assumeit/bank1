import React from 'react';

const Logout = () => {
  return <h1>Logout Page</h1>;
};

export default Logout;
