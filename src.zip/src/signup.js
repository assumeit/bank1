import React from 'react';

const Signup = () => {
  return <h1>Sign Up Page</h1>;
};

export default Signup;
