import React from 'react';

const Home = () => {
  return <h1></h1>;
};

export default Home;
